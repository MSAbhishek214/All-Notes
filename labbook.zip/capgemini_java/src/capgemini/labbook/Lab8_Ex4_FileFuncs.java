package capgemini.labbook;

import java.io.File;
import java.util.Scanner;

public class Lab8_Ex4_FileFuncs {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String fileInput = sc.next();
		File file=new File("C:\\Users\\abrotti\\Desktop\\" + fileInput);
		System.out.println(file.exists());
		System.out.println(file.canRead());
		System.out.println(file.canWrite());
		System.out.println(fileInput.split("[.]")[1] + "File");
		System.out.println(file.getTotalSpace() + " Bytes");
		sc.close();
	}

}
