package capgemini.labbook;

public class Lab2_Ex1_LibraryClient {

	public static void main(String[] args) {

		WrittenItem wi1 = new Book("Subhajit");
		WrittenItem wi2 = new JournalPaper("1947");
		MediaItem mi1 = new Video("Abhishek", "Pop", "1997");
		MediaItem mi2 = new CD("Apurwa", "Rock");

		System.out.println("Details of Book>>>>>>>>");
		wi1.addItem();
		wi1.checkIn();
		wi1.checkOut();
		wi1.print();

		System.out.println("Details of Journal Paper>>>>>>");

		wi2.addItem();
		wi2.checkIn();
		wi2.checkOut();
		wi2.print();

		System.out.println("Details of Video>>>>>>>>");

		mi1.addItem();
		mi1.checkIn();
		mi1.checkOut();
		mi1.print();

		System.out.println("Details of CD>>>>>>>>");

		mi2.addItem();
		mi2.checkIn();
		mi2.checkOut();
		mi2.print();

		System.out.println(wi1);
		System.out.println(wi2);
		System.out.println(mi1);
		System.out.println(mi2);
	}

}
