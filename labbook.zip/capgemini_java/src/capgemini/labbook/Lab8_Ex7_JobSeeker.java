package capgemini.labbook;

import java.util.HashMap;
import java.util.Scanner;

public class Lab8_Ex7_JobSeeker {
	static boolean validator(String str) {
		int ical = str.indexOf("_");
		if (str.substring(0, ical).length() >= 8 && str.endsWith("_job"))
			return true;
		else
			return false;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String name = sc.next();
		System.out.println(validator(name));
		sc.close();
	}

}
 