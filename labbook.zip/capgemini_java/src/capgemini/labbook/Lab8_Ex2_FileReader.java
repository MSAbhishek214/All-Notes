package capgemini.labbook;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;

public class Lab8_Ex2_FileReader {

	public static void main(String[] args) {

		//Scanner sc = new Scanner(System.in);
		String line = null;

		File file = new File("C:\\Users\\abrotti\\Desktop\\Reader.txt");

		try (FileReader fr = new FileReader(file)) {
			LineNumberReader lnr = new LineNumberReader(fr);
			while ((line = lnr.readLine()) != null)
				System.out.println(lnr.getLineNumber() + " " + line);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
