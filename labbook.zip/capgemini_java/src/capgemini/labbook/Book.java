package capgemini.labbook;

public class Book extends WrittenItem{

	public Book() {
		super();
	}

	public Book(String author) {
		super(author);
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Book []");
		return builder.toString();
	}

	@Override
	public void checkIn() {
		// TODO Auto-generated method stub
		System.out.println("Checked in...");
	}

	@Override
	public void checkOut() {
		// TODO Auto-generated method stub
		System.out.println("Checked out...");
	}

	@Override
	public void addItem() {
		// TODO Auto-generated method stub
		System.out.println("Added Item...");
	}

	@Override
	public void print() {
		// TODO Auto-generated method stub
		System.out.println("Details have been printed...");
	}

	
}
