package capgemini.labbook;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Scanner;

public class Lab9_Ex1_HashToList {
	static Collection<String> HashToList(HashMap<Integer,String> hashmap){
		ArrayList<String> list=new ArrayList<String>();
		
		for(Integer ks  :hashmap.keySet()){
			list.add(hashmap.get(ks));
		}
		Collections.sort(list);
		
		return list;
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		HashMap<Integer,String> hashmap=new HashMap<Integer,String>();
		hashmap.put(sc.nextInt(),sc.next());
		hashmap.put(sc.nextInt(),sc.next());
		hashmap.put(sc.nextInt(),sc.next());
		hashmap.put(sc.nextInt(),sc.next());
		hashmap.put(sc.nextInt(),sc.next());
		System.out.println(HashToList(hashmap).toString());
		sc.close();
	}

}
