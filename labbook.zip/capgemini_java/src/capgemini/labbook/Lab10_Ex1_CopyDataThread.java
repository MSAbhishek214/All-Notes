package capgemini.labbook;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class Lab10_Ex1_CopyDataThread extends Thread {

	@Override
	public void run() {
		File source = new File("C:\\Users\\abrotti\\Desktop\\Source.txt");
		File target = new File("C:\\Users\\abrotti\\Desktop\\Target.txt");
		int character, counter = 0;
		try (FileReader fr = new FileReader(source); FileWriter fw = new FileWriter(target)) {
			while ((character = fr.read()) != -1) {
				fw.write(character);
				counter++;
				if(counter == 10) {
					System.out.println("10 chararcters have been printed...");
					TimeUnit.SECONDS.sleep(5);
					counter = 0;
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		Thread t1 = new Lab10_Ex1_CopyDataThread();
		t1.start();
	}
}
