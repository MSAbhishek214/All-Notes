package capgemini.labbook;

import java.util.function.Supplier;

class Person1 {
	String name;
	int age;

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	@Override
	public String toString() {
		return "Person1 [name=" + name + ", age=" + age + "]";
	}
}
public class Lab13_Ex4_InstanceCreation {

	public static void main(String[] args) {
		Supplier<Person1> supplierPerson=Person1::new;
		Person1 person=supplierPerson.get();
		person.setName("Aamir");
		person.setAge(23);
		System.out.println(person);
		
	}

}
