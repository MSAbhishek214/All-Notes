package capgemini.labbook;

public class EmployeeException extends Exception{

	public EmployeeException(String message) {
		super(message);
	}
	
	@Override
	public String getMessage() {
		return super.getMessage() + " Salary of the employee is below 3000 rupees!!!";
	}
}
