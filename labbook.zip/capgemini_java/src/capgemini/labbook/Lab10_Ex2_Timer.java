package capgemini.labbook;

import java.time.LocalTime;

public class Lab10_Ex2_Timer implements Runnable {
	@Override
	public void run() {
		while (true) {
			System.out.println(LocalTime.now());
			try {
				Thread.sleep(10000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	public static void main(String[] args) {
		Runnable runnable = new Lab10_Ex2_Timer();
		Thread t1 = new Thread(runnable);
		t1.start();

	}
}