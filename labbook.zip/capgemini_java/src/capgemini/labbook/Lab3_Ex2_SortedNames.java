package capgemini.labbook;

import java.util.Arrays;
import java.util.Scanner;

public class Lab3_Ex2_SortedNames {

	static String[] SortedNames(String[] arr)
	{
		Arrays.sort(arr);
		if(arr.length % 2 ==0)
		{
			for(int i=0;i<arr.length/2;i++)
				arr[i]=arr[i].toUpperCase();
			for(int i=arr.length/2;i<arr.length;i++)
				arr[i]=arr[i].toLowerCase();
		}
		else
		{
			for(int i=0;i<(arr.length/2)+1;i++)
				arr[i]=arr[i].toUpperCase();
			for(int i=(arr.length/2)+1;i<arr.length;i++)
				arr[i]=arr[i].toLowerCase();
		}
		return arr;
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		String [] arr=new String[n];
		for(int i=0;i<n;i++)
			arr[i]=sc.next();
		String [] narr=SortedNames(arr);
		for(int i=0;i<narr.length;i++)
			System.out.println(narr[i]);
		
		sc.close();
	}

}
