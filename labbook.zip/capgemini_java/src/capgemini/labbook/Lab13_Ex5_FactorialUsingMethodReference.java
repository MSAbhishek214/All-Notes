package capgemini.labbook;

import java.util.Scanner;
import java.util.function.Function;

public class Lab13_Ex5_FactorialUsingMethodReference {
	public static int getFactorial(int num) {
		if (num == 0 || num == 1) {
			return 1;
		} else
			return (num * getFactorial(num - 1));
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int number = sc.nextInt();
		Function<Integer, Integer> factorial = Lab13_Ex5_FactorialUsingMethodReference::getFactorial;
		System.out.println("Factorial of " + number + " is :" + factorial.apply(number));
		sc.close();
	}

}
