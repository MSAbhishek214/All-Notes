package capgemini.labbook;

import java.util.Scanner;

public class Lab5_Ex5_AgeException {

	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);
		try {
			int Age=sc.nextInt();
			sc.close();
			if (Age < 15)
				throw new AgeException("InApproriate age:");
		} catch (AgeException e) {
			e.printStackTrace();
		}
	
	}
	

}
