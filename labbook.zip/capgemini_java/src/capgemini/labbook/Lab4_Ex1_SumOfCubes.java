package capgemini.labbook;

import java.util.Scanner;

public class Lab4_Ex1_SumOfCubes {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n, temp, d, sum = 0;
		n = sc.nextInt();
		temp = n;
		while (temp != 0) {
			d = temp % 10;
			sum += Math.pow(d, 3);
			temp = temp / 10;
		}
		System.out.println("Sum of Cubes of the n digit number is:" + sum);
		sc.close();
	}

}
