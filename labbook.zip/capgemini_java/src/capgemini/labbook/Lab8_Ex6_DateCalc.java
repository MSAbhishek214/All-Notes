package capgemini.labbook;
import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;

public class Lab8_Ex6_DateCalc {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		LocalDate date = LocalDate.of(2002, 1, 12);
		LocalDate ld = LocalDate.now();
		Period diff = Period.between(date, ld);
		System.out.println("Number of Years" + diff.getYears());
		System.out.println("Number of Months" + diff.getMonths());
		System.out.println("Number of Days" + diff.getDays());
		sc.close();

	}

}
