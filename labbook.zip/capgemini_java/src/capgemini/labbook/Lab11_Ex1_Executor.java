package capgemini.labbook;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalTime;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class Lab11_Ex1_Executor {

	public static void main(String[] args) {

		ExecutorService exserv = Executors.newFixedThreadPool(1);
		Executor executor = Executors.newSingleThreadExecutor();

		Runnable task1 = () -> {
			File source = new File("C:\\Users\\abrotti\\Desktop\\Source.txt");
			File target = new File("C:\\Users\\abrotti\\Desktop\\Target.txt");
			int character, counter = 0;
			try (FileReader fr = new FileReader(source); FileWriter fw = new FileWriter(target)) {
				while ((character = fr.read()) != -1) {
					fw.write(character);
					counter++;
					if (counter == 10) {
						System.out.println("10 chararcters have been printed...");
						TimeUnit.SECONDS.sleep(5);
						counter = 0;
					}
				}
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e1) {
				e1.printStackTrace();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		};
		
		Runnable task2 = () -> {
			while (true) {
				System.out.println(LocalTime.now());
				try {
					Thread.sleep(10000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		};
		executor.execute(task1);
		
		exserv.submit(task2);
		
	}

}
