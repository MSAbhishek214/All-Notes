
package capgemini.labbook;

import java.util.Scanner;

public class Lab1_ex2_calculateDifference {
	static int calculateDifference(int n) {
		int sum1 = 0, sum2 = 0, sum = 0;
		for (int i = 1; i <= n; i++)
			sum1 += i * i;
		for (int i = 1; i <= n; i++)
			sum2 += i;
		sum2 *= sum2;
		sum = sum2 - sum1;
		return sum;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		System.out.println(calculateDifference(n));
	}
}
