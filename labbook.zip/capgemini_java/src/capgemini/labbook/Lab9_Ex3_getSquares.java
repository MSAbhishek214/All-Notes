package capgemini.labbook;

import java.util.HashMap;
import java.util.Scanner;	
public class Lab9_Ex3_getSquares {
static HashMap<Integer, Integer> getSquares(int []arr){
	HashMap<Integer, Integer> hashmap=new HashMap<Integer, Integer>();
		for(int i=0;i<arr.length;i++){
			hashmap.put(arr[i], (int)Math.pow(arr[i], 2));
		}
		return hashmap;
		
	}
	public static void main(String args[]){
	Scanner sc=new Scanner(System.in);
	int n=sc.nextInt();
	int arr[]=new int[n];
	for(int i=0;i<n;i++){
		arr[i]=sc.nextInt();
	}
	System.out.println(getSquares(arr));
	sc.close();
	}
}
