package capgemini.labbook;

import java.util.Scanner;

public class Lab5_Ex3_PrimeNumbers {

	static void PrimeNumbers(int n) {
		boolean flag = true;
		int i;
		for (i = 2; i <= n / 2; i++) {
			if (n % i == 0) {
				flag = false;
				break;
			}
		}
		if (flag == true) {
			System.out.println("Prime number is: " + n);

		}
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		for (int i = 2; i <= n; i++) {
			PrimeNumbers(i);
		}
		sc.close();
	}

}
