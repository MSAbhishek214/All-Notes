package capgemini.labbook;

public class Video extends MediaItem {

	private String director;
	private String genre;
	private String yearReleased;

	public Video() {
		super();
	}

	public Video(String director, String genre, String yearReleased) {
		super();
		this.director = director;
		this.genre = genre;
		this.yearReleased = yearReleased;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((director == null) ? 0 : director.hashCode());
		result = prime * result + ((genre == null) ? 0 : genre.hashCode());
		result = prime * result + ((yearReleased == null) ? 0 : yearReleased.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Video other = (Video) obj;
		if (director == null) {
			if (other.director != null)
				return false;
		} else if (!director.equals(other.director))
			return false;
		if (genre == null) {
			if (other.genre != null)
				return false;
		} else if (!genre.equals(other.genre))
			return false;
		if (yearReleased == null) {
			if (other.yearReleased != null)
				return false;
		} else if (!yearReleased.equals(other.yearReleased))
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Video [director=").append(director).append(", genre=").append(genre).append(", yearReleased=")
				.append(yearReleased).append("]");
		return builder.toString();
	}

	public String getDirector() {
		return director;
	}

	public void setDirector(String director) {
		this.director = director;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public String getYearReleased() {
		return yearReleased;
	}

	public void setYearReleased(String yearReleased) {
		this.yearReleased = yearReleased;
	}

	@Override
	public void checkIn() {
		// TODO Auto-generated method stub
		System.out.println("Checked in...");
	}

	@Override
	public void checkOut() {
		// TODO Auto-generated method stub
		System.out.println("Checked out...");
	}

	@Override
	public void addItem() {
		// TODO Auto-generated method stub
		System.out.println("Added Item...");
	}

	@Override
	public void print() {
		// TODO Auto-generated method stub
		System.out.println("Details have been printed...");
	}

}
