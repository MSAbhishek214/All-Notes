
package capgemini.labbook;

import java.util.Scanner;

public class Lab1_Ex3_checkNumber {

	static boolean checkNumber(int number) {
		boolean isIncreasing = true;
		String sNum = Integer.toString(number);
		String[] arr = new String[10];
		arr = sNum.split("");
		for (int i = 0; i < arr.length - 1; i++) {
			if (Integer.parseInt(arr[i]) >= Integer.parseInt(arr[i + 1])) {
				isIncreasing = false;

			}
		}
		return isIncreasing;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		if (checkNumber(n))
			System.out.println(n + " is an increasing number");
		else
			System.out.println(n + " is not an increasing number");
	}

}
