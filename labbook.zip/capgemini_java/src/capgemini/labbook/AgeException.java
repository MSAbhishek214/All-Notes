package capgemini.labbook;

public class AgeException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	AgeException(String message)
	{
		super(message);
	}
	@Override
	public String getMessage()
	{
		return super.getMessage()+" Age of the person should be above 15...";
	}
}
