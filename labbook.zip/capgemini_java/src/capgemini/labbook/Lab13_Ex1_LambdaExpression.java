package capgemini.labbook;

import java.util.function.BiFunction;

public class Lab13_Ex1_LambdaExpression {

	public static void main(String[] args) {
		int a=4;
		int b=2;
		BiFunction<Integer, Integer, Integer> powerFunc=(x,y) -> {return (int) Math.pow(x,y);};
		System.out.println(powerFunc.apply(a,b));
	}
}
