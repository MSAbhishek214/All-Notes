package capgemini.labbook;

import java.util.Arrays;
import java.util.Scanner;

public class Array {

	static int[] odd(int arr[])
	{
		int oarr[]=new int[arr.length];
		int c=0;
		for(int i=0;i<arr.length;i++)
		{
			if(arr[i]%2 !=0)
				oarr[c++]+=arr[i];
		}
		return oarr;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		int i, n;
		n = sc.nextInt();
		int arr[]=new int[n];
		for (i = 0; i < n; i++)
			arr[i] = sc.nextInt();
		int[] narr = odd(arr);
		
		for(i=0;i<n;i++) {
			if(narr[i] != 0)
				System.out.print(narr[i]+"\t");
		}
		sc.close();
	}

}
