package capgemini.labbook;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;

public class Lab8_Ex3_TextReader {

	public static void main(String[] args) {
		//int line;
		int ch;
		int cha = 0, sp = 0,c=0;
		File file = new File("C:\\Users\\abrotti\\Desktop\\TextReader.txt");
		try (FileReader fr = new FileReader(file)) {
			LineNumberReader lnr1 = new LineNumberReader(fr);
			while ((ch = lnr1.read()) != -1) {
				if ((char)ch == ' ') {
					sp++;
				}
				else if((char)ch == '\n') {
					sp++;
					c++;
				}
				else {
					cha++;
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		System.out.println("Total number of lines in the text is :" + cha);
		System.out.println("Total number of words in the text is :" + (sp + 1));
		System.out.println("The total number of lines in the text is: "+(c+1));
	}

}
