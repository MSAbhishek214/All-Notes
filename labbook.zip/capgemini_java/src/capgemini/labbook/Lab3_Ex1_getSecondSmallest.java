
package capgemini.labbook;

import java.util.Arrays;
import java.util.Scanner;


public class Lab3_Ex1_getSecondSmallest {

	static int getSecondSmallest(int[] arr)
	{
		Arrays.sort(arr);
		return(arr[1]);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int arr[]=new int[n];
		for(int i=0;i<n;i++)
			arr[i]=sc.nextInt();
		System.out.println(getSecondSmallest(arr));
		sc.close();
	}

}
