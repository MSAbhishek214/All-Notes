package capgemini.labbook;

import java.util.Scanner;
import java.util.StringTokenizer;

public class Lab8_Ex1_StringTokenizer {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		String integers = sc.next();
		int sum = 0;

		StringTokenizer st = new StringTokenizer(integers, ",");

		while (st.hasMoreElements()) {
			String num = (String) st.nextElement();
			System.out.println(num);
			sum += Integer.parseInt(num);
		}
		System.out.println(sum);
		sc.close();
	}

}
