package capgemini.labbook;

import java.util.function.Function;

public class Lab13_Ex2_SpaceBetweenString {

	public static void main(String[] args) {
		String input="CG";
		Function<String,String> insertSpace=(in) -> {return input.replace(""," ").trim();};
		System.out.println(insertSpace.apply(input));
	}
}
