package capgemini.labbook;

import java.util.HashMap;
import java.util.Scanner;

public class Lab9_Ex2_CountChar {

	static HashMap<Character, Integer> countCharacter (char[] chars) {
		HashMap<Character, Integer> hashmap = new HashMap<Character, Integer>();
		for (char ch = 'A'; ch < 'Z'; ch++) {
			int c = 0;
			for (int i = 0; i < chars.length; i++) {
				if (chars[i] == ch)
					c++;
			}
			if (c > 0)
				hashmap.put(ch, c);
		}
		for (char ch = 'a'; ch < 'z'; ch++) {
			int c = 0;
			for (int i = 0; i < chars.length; i++) {
				if (chars[i] == ch)
					c++;
			}
			if (c > 0)
				hashmap.put(ch, c);
		}
		return hashmap;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String s = sc.next();
		char[] chars = s.toCharArray();
		System.out.println(countCharacter (chars).toString());
		sc.close();
	}

}
