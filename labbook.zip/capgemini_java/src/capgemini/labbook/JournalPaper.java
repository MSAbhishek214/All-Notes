package capgemini.labbook;

public class JournalPaper extends WrittenItem {

	private int yearPublished;

	public JournalPaper() {
		super();
	}

	public JournalPaper(String author) {
		super(author);
	}

	public JournalPaper(int yearPublished) {
		super();
		this.yearPublished = yearPublished;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + yearPublished;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		JournalPaper other = (JournalPaper) obj;
		if (yearPublished != other.yearPublished)
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("JournalPaper [yearPublished=").append(yearPublished).append("]");
		return builder.toString();
	}

	public int getYearPublished() {
		return yearPublished;
	}

	public void setYearPublished(int yearPublished) {
		this.yearPublished = yearPublished;
	}

	public void checkIn() {
		// TODO Auto-generated method stub
		System.out.println("Checked in...");
	}

	@Override
	public void checkOut() {
		// TODO Auto-generated method stub
		System.out.println("Checked out...");
	}

	@Override
	public void addItem() {
		// TODO Auto-generated method stub
		System.out.println("Added Item...");
	}

	@Override
	public void print() {
		// TODO Auto-generated method stub
		System.out.println("Details have been printed...");
	}


}
