package capgemini.labbook;

public class MyException extends Exception {
	MyException(String message)
	{
		super(message);
	}
	@Override
	public String getMessage()
	{
		return super.getMessage()+" First & Last names should not be empty";
	}
}
