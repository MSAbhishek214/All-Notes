package capgemini.labbook;

import java.util.Scanner;

public class Lab5_Ex2_Fibonacci {
	static void NRFibonacci(int n) {
		int a = 0, b = 1, c = 0;
		while (n > 0) {
			System.out.println(a + "\t");
			c = a + b;
			a = b;
			b = c;
			n--;
		}
	}

	static int RFibonacci(int n) {
		if (n == 0 || n == 1)
			return n;
		else {
			return RFibonacci(n - 1) + RFibonacci(n - 2);
		}
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		NRFibonacci(n);
		System.out.println(RFibonacci(n));
		sc.close();
	}

}
