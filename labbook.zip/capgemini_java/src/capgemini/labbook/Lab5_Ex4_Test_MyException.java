package capgemini.labbook;

public class Lab5_Ex4_Test_MyException {

	public static void main(String[] args) {

		try {
			String first_name = "";
			String last_name = "";
			if (first_name == "" && last_name == "")
				throw new MyException("No names found");
		} catch (MyException e) {
			e.printStackTrace();
		}

	}

}
