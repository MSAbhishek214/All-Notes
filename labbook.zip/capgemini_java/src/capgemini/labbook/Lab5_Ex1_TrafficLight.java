package capgemini.labbook;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JRadioButton;

class RadioButtonLight extends JFrame implements ActionListener
{
	private static final long serialVersionUID = 1L;
	JRadioButton green,red,yellow;
	public RadioButtonLight()
	{
		red=new JRadioButton("Red");    
		red.setBounds(100,50,100,30);  
		
		yellow=new JRadioButton("Yellow");    
		yellow.setBounds(100,100,100,30);
		
		green=new JRadioButton("Green");    
		green.setBounds(100,150,100,30);
		
		ButtonGroup bg=new ButtonGroup();  
		bg.add(red);
		bg.add(yellow);
		bg.add(green);    
		red.addActionListener(this);   
		yellow.addActionListener(this);
		green.addActionListener(this);
		add(red);
		add(yellow);
		add(green);   
		setSize(300,300);    
		setLayout(null);    
		setVisible(true);  
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(red.isSelected())
		{
			System.out.println("Stop");
		}
		if(yellow.isSelected())
		{
			System.out.println("Wait");
		}
		if(green.isSelected())
		{
			System.out.println("Go");
		}
		
	}
}
public class Lab5_Ex1_TrafficLight {

	public static void main(String[] args) {
		new RadioButtonLight();

	}

}
