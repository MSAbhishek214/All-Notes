package capgemini.labbook;

public class CD extends MediaItem{

	private String artist;
	private String genre;

	public CD() {
		super();
	}

	public CD(String artist, String genre) {
		super();
		this.artist = artist;
		this.genre = genre;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((artist == null) ? 0 : artist.hashCode());
		result = prime * result + ((genre == null) ? 0 : genre.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CD other = (CD) obj;
		if (artist == null) {
			if (other.artist != null)
				return false;
		} else if (!artist.equals(other.artist))
			return false;
		if (genre == null) {
			if (other.genre != null)
				return false;
		} else if (!genre.equals(other.genre))
			return false;
		return true;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("CD [artist=").append(artist).append(", genre=").append(genre).append("]");
		return builder.toString();
	}

	public String getArtist() {
		return artist;
	}

	public void setArtist(String artist) {
		this.artist = artist;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public void checkIn() {
		// TODO Auto-generated method stub
		System.out.println("Checked in...");
	}

	@Override
	public void checkOut() {
		// TODO Auto-generated method stub
		System.out.println("Checked out...");
	}

	@Override
	public void addItem() {
		// TODO Auto-generated method stub
		System.out.println("Added Item...");
	}

	@Override
	public void print() {
		// TODO Auto-generated method stub
		System.out.println("Details have been printed...");
	}


}
