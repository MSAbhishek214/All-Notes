
package capgemini.labbook;
import java.util.Scanner;
public class Lab1_Ex4_checkNumber {
	static boolean checkNumber(int n) {
		for (int i = 1; i <= n; i++) {
			if (Math.pow(2, i) == n) {
				return true;
			}
		}
		return false;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		if (checkNumber(n))
			System.out.println(n + " is a power of 2");
		else
			System.out.println(n + " is not a power of 2");
	}
}
