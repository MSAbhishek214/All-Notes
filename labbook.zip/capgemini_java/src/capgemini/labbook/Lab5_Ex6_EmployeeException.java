package capgemini.labbook;

import java.util.Scanner;

public class Lab5_Ex6_EmployeeException {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		try {
		double salary=sc.nextDouble();
			sc.close();
			if (salary < 3000)
				throw new EmployeeException("Insufficient salary: ");
		} catch (EmployeeException e) {
			e.printStackTrace();
		}
	
	}

}
