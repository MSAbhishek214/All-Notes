package capgemini.labbook;

import java.util.Arrays;
import java.util.Scanner;

public class Lab3_Ex2_getSorted {

	static int[] getSorted(int[] unarr) {
		for (int i = 0; i < unarr.length; i++) {
			int rev = 0;
			int temp = unarr[i];
			while (temp != 0) {
				int d = temp % 10;
				rev = rev * 10 + d;
				temp = temp / 10;
			}
			unarr[i] = rev;
		}
		Arrays.sort(unarr);
		return unarr;
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int[] unarr = new int[n];
		for (int i = 0; i < unarr.length; i++) {
			unarr[i] = sc.nextInt();
		}
		int[] soarr = getSorted(unarr);
		for (int so : soarr) {
			System.out.print(so + "\t");
		}
		sc.close();
	}

}
