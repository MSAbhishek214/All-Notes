package capgemini.labbook;

import java.util.Scanner;
import java.util.function.Predicate;

public class Lab13_Ex3_UserNameValidate {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		String userName=s.next();
		String password=s.next();
		Predicate<String> isUserNameValid=(username)->(!userName.isEmpty() && userName.equals("Apurwa"));
		Predicate<String> isPasswordValid=(passWord)->(!password.isEmpty() && password.equals("Apurwa"));
		System.out.println(isUserNameValid.test(userName));
		System.out.println(isPasswordValid.test(password));
		s.close();
	}

}
