package capgemini.labbook;

import java.util.Scanner;

public class Lab3_Ex4_CharacterCount {

	static void CharacterCount(char[] chars) {
		for (char ch = 'A'; ch < 'Z'; ch++) {
			int c = 0;
			for (int i = 0; i < chars.length; i++) {
				if (chars[i] == ch)
					c++;
			}
			if (c > 0)
				System.out.println("The frequency of the charcter " + ch + "is" + c);
		}
		for (char ch = 'a'; ch < 'z'; ch++) {
			int c = 0;
			for (int i = 0; i < chars.length; i++) {
				if (chars[i] == ch)
					c++;
			}
			if (c > 0)
				System.out.println("The frequency of the charcter " + ch + "is" + c);
		}
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String s = sc.next();
		char[] chars = s.toCharArray();
		CharacterCount(chars);
		sc.close();
	}

}
