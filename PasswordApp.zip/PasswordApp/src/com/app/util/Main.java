package com.app.util;

import java.util.Scanner;
import java.io.*;
public class Main
{

        public static void main(String args[])
        {
           
            Scanner sc = new Scanner(System.in);
            String input = sc.next();
            System.out.println(generate(input));
            sc.close();
        }


        public static String generate(String s) 
        {
            StringBuilder sb = new StringBuilder();
            if(s.length() >= 5) {
            	for (int i = 0; i < s.length(); i += 2) {
					sb.append(s.charAt(i));
				}
            	return sb.toString().toUpperCase();
            }
            else {
            	return "Invalid Input";
            }
        }
}
