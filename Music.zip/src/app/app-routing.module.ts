import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddAlbumComponent } from './music/add-album.component';
import { AlbumListComponent } from './music/album-list.component';
import { HomeComponent } from './music/home.component';
import { SearchAlbumComponent } from './music/search-album.component';
import { UpdateAlbumComponent } from './music/update-album.component';


const routes: Routes = [
  {path: "add-album", component: AddAlbumComponent},
  {path: "album-list", component: AlbumListComponent},
  {path: "", component:HomeComponent},
  {path: "search-album", component: SearchAlbumComponent},
  {path: "update/:id", component: UpdateAlbumComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
