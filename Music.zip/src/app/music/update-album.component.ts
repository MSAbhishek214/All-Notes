import { Component, OnInit } from '@angular/core';
import { MusicService } from './music.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Album } from './music.interface';

@Component({
  selector: 'app-update-album',
  templateUrl: './update-album.component.html',
  styleUrls: ['./update-album.component.css']
})
export class UpdateAlbumComponent implements OnInit {

  album: Album;
  constructor(private musicService: MusicService, 
    private activatedRoute: ActivatedRoute, 
    private router: Router) { }

  ngOnInit() {
    let albumID = this.activatedRoute.snapshot.params["id"];
    this.album=this.musicService.getAlbums().find(e=>e.id==albumID)
  }

  navigateBack() {
    this.router.navigate(['/album-list']);
  }

  onsave(album){
    this.musicService.onsave(album);
    this.router.navigate(['/album-list']);
  } 



}
