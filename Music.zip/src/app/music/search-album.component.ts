import { Component, OnInit } from '@angular/core';
import { MusicService } from './music.service';
import { Album } from './music.interface';

@Component({
  selector: 'app-search-album',
  templateUrl: './search-album.component.html',
  styleUrls: ['./search-album.component.css']
})
export class SearchAlbumComponent implements OnInit {

  albums: Album[];
  constructor(private musicService: MusicService) { }

  ngOnInit() {
  }

  search(data) {
    this.albums = this.musicService.getAlbums().filter(emp => emp.title == data.searchTerm);
    if(this.albums.length == 0) {
      this.albums = this.musicService.getAlbums().filter(emp => emp.artist == data.searchTerm)
    }
  }

}
