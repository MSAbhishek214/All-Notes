import { Injectable } from '@angular/core';
import { Album } from './music.interface';
import { Observable } from 'rxjs';
import { HttpClient } from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class MusicService {

  albums: Album[];

  constructor(private http: HttpClient) {
    this.populateAlbums().subscribe(data => this.albums = data, error => console.log(error));
  }

  populateAlbums(): Observable<Album[]> {
    return this.http.get<Album[]>("../../assets/albums.json");
  }

  getAlbums(): Album[] {
    return this.albums;
  }

  addAlbum(album: Album) {
    this.albums.push(album);
  }

  deleteAlbums(id) {
    if(confirm("Are you sure you want to delete?")) {
      this.albums = this.albums.filter(album => album.id != id);
    }
  }

  onsave(album:Album){

    let index=this.albums.findIndex(music=>music.id===album.id)
    this.albums[index].id=album.id;
    this.albums[index].title=album.title;
    this.albums[index].artist=album.artist;
    this.albums[index].price=album.price;
   alert("Details Saved");
  }


}
