import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { MusicService } from './music.service';
import { Router } from '@angular/router';
import { Album } from './music.interface';

@Component({
  selector: 'app-add-album',
  templateUrl: './add-album.component.html',
  styleUrls: ['./add-album.component.css']
})
export class AddAlbumComponent implements OnInit {

  @ViewChild("userForm", {static: false})
  public createAlbumForm: NgForm
  
  constructor(private musicService: MusicService, private router: Router) { }

  ngOnInit() {
  }

  onSubmit(album: Album) {
    this.musicService.addAlbum(album)
    this.router.navigate(['/album-list'])
  }

}
