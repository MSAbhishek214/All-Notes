import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './music/home.component';
import { FormsModule } from "@angular/forms";
import { AddAlbumComponent } from './music/add-album.component';
import { AlbumListComponent } from './music/album-list.component';
import { HttpClientModule } from '@angular/common/http';
import { MusicService } from './music/music.service';
import { SearchAlbumComponent } from './music/search-album.component';
import { UpdateAlbumComponent } from './music/update-album.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AddAlbumComponent,
    AlbumListComponent,
    SearchAlbumComponent,
    UpdateAlbumComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [MusicService],
  bootstrap: [AppComponent]
})
export class AppModule { }
