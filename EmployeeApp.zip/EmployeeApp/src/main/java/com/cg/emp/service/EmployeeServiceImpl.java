package com.cg.emp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.emp.Exceptions.EmployeeException;
import com.cg.emp.beans.Employee;
import com.cg.emp.dao.EmployeeRepository;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeRepository employeeRepostiory;

	@Override
	public List<Employee> getAllEmployees() throws EmployeeException {
		try {
			return employeeRepostiory.findAll();
		} catch (Exception e) {
			throw new EmployeeException(e.getMessage());
		}
	}

	@Override
	public List<Employee> addEmployee(Employee employee) throws EmployeeException {
		if(employeeRepostiory.existsById(employee.getId())) {
			throw new EmployeeException("Employee with ID " + employee.getId() + " already exists!");
		}
		employeeRepostiory.save(employee);
		return getAllEmployees();
	}

	@Override
	public Employee getEmployeeById(int id) throws EmployeeException {
		if(!employeeRepostiory.existsById(id)) {
			throw new EmployeeException("Employee with ID " + id +" does not exist!");
		}
		return employeeRepostiory.findById(id).get();
	}

	@Override
	public List<Employee> deleteEmployee(int id) throws EmployeeException {
		if(!employeeRepostiory.existsById(id)) {
			throw new EmployeeException("Employee with ID " + id + " does not exists and cannot be deleted!");
		}
		employeeRepostiory.deleteById(id);
		return getAllEmployees();
	}

	@Override
	public List<Employee> updateEmployee(Employee employee) throws EmployeeException {
		return null;
	}

}
