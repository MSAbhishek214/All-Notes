package com.cg.emp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.emp.Exceptions.EmployeeException;
import com.cg.emp.beans.Employee;
import com.cg.emp.service.EmployeeService;

@RestController
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;
	
	@RequestMapping("/employees")
	public List<Employee> getAllEmployees() throws EmployeeException {
		return employeeService.getAllEmployees();
	}
	
	@GetMapping("/employees/{id}")
	public Employee getEmployeeById(@PathVariable int id) throws EmployeeException {
		return employeeService.getEmployeeById(id);
	}
	
	@PostMapping("/employees")
	public List<Employee> addEmployees(@RequestBody Employee employee) throws EmployeeException {
		return employeeService.addEmployee(employee);
	}
	
	@DeleteMapping("employees/{id}")
	public List<Employee> deleteEmployees(@PathVariable int id) throws EmployeeException {
		return employeeService.deleteEmployee(id);
	}
}
