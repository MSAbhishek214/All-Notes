package com.cg.student.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.student.beans.Student;
import com.cg.student.dao.StudentRepository;
import com.cg.student.exceptions.StudentException;

@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	private StudentRepository studentRepository;

	@Override
	public List<Student> getAllStudents() throws StudentException {
		return studentRepository.findAll();
	}

	@Override
	public List<Student> addStudent(Student student) throws StudentException {
		if (studentRepository.existsById(student.getId())) {
			throw new StudentException("Student with ID" + student.getId() + " already exists");
		}
		studentRepository.save(student);
		return getAllStudents();
	}

	@Override
	public List<Student> deleteStudent(int id) throws StudentException {
		if (!studentRepository.existsById(id)) {
			throw new StudentException("Student ID " + id + " does not exist and cannot be deleted");
		}
		studentRepository.deleteById(id);
		return getAllStudents();
	}

	@Override
	public List<Student> updateStudent(Student student, int id) throws StudentException {
		if (!studentRepository.existsById(id)) {
			throw new StudentException("Student Id " + id + " does not exist, update operation disallowed");
		}
		Student originalStudent = studentRepository.findById(id).get();
		originalStudent.setName(student.getName());
		originalStudent.setAge(student.getAge());
		originalStudent.setStream(student.getStream());
		studentRepository.save(originalStudent);
		return getAllStudents();
	}

	@Override
	public List<Student> getStudentsByStream(String stream) throws StudentException {
		return studentRepository.getStudentsByStream(stream);
	}

}
