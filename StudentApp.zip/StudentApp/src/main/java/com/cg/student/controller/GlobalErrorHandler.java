package com.cg.student.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.cg.student.exceptions.StudentException;

@ControllerAdvice
public class GlobalErrorHandler {

	@ExceptionHandler({ StudentException.class })
	public ResponseEntity<String> handleError(Exception ex) {
		return new ResponseEntity<String>(ex.getMessage(), HttpStatus.CONFLICT);
	}
}
