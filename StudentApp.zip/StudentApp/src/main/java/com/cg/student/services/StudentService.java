package com.cg.student.services;

import java.util.List;

import com.cg.student.beans.Student;
import com.cg.student.exceptions.StudentException;

public interface StudentService {

	List<Student> getAllStudents() throws StudentException;

	List<Student> addStudent(Student student) throws StudentException;

	List<Student> deleteStudent(int id) throws StudentException;

	List<Student> updateStudent(Student student, int id) throws StudentException;

	List<Student> getStudentsByStream(String stream) throws StudentException;
}
