package com.cg.student.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.student.beans.Student;
import com.cg.student.exceptions.StudentException;
import com.cg.student.services.StudentService;

@RestController
public class StudentController {

	@Autowired
	private StudentService studentService;
	
	@RequestMapping("/students")
	public List<Student> getAllStudents() throws StudentException {
		return studentService.getAllStudents();
	}

	@PostMapping("/students")
	public List<Student> addStudent(@Valid @RequestBody Student student) throws StudentException {
		return studentService.addStudent(student);
	}
	
	@DeleteMapping("/students/{id}")
	public List<Student> deleteStudent(@PathVariable int id) throws StudentException {
		return studentService.deleteStudent(id);
	}
	
	@PutMapping("/students/update/{id}")
	public List<Student> updateStudent(@RequestBody Student student, @PathVariable int id) throws StudentException {
		return studentService.updateStudent(student, id);
	}
	
	@GetMapping("/students/stream")
	public List<Student> getStudentByStream(@RequestParam String stream) throws StudentException {
		return studentService.getStudentsByStream(stream);
	}
}
