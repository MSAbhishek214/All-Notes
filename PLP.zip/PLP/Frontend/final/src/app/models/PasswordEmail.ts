export class PasswordEmail{

    emailid:string
    password:string
}