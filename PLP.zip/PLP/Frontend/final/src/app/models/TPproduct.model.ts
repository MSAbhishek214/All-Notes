import { TPMerchant } from './tpMerchant.model';

export class TPProduct{
    productID:number;
    productName:string;
    merchant:TPMerchant;
    tag:string[]=[];
    company:string;
    photo:string;
    description:string;
    quantity:number;
    category:string;
    subcategory:string;
    soldQuantities:number;
    price:number;
    releaseDate:Date;

}