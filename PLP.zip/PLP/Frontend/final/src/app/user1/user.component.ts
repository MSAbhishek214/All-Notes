export class User1{
    constructor(
      public userId:number=0,
      public emailid:string="",
      public firstName:string="",
      public lastName:string="",
      public password:string="",
      public mobileNo:number=0,
      public address:string="",
      public photo:string=""
      
    ){}
  }