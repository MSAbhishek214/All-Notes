import { Component } from '@angular/core';
import { RatingService } from '../../Services/Ratingservice';

import { Review } from '../../models/review';
import { Router } from '@angular/router';

@Component({
    selector: 'add',
    templateUrl: 'ran.html'
})

export class AppratingComponent { 
    
    constructor(private service:RatingService,private router:Router){

    }
     rating:number;
     userId:number;
     productId:number;
     reviewFeedback:string
     stars:number;


    submit(){
        var userid = sessionStorage.getItem("user");
        var productid = sessionStorage.getItem("productId");
        var ob:Review=new Review(userid,productid,"Good Product Great Quality",this.rating);
        this.service.rate(ob).subscribe(data=>console.log(data));
         alert("Review added successfully");
        
        
    }
    
    backtohome(){
        window.location.replace("http://localhost:4200/home");
    }
}