import { Component } from "@angular/core";
import { InvoiceService } from "src/app/Services/InvoiceService";
import { Product1 } from "src/app/models/product";
import { Invoice } from "src/app/models/Invoice";
import { Router } from "@angular/router";


@Component
    (
        {
            selector: "showinvo",
            templateUrl: "show.html"
        }
    )

export class showInvoice {
    orderid: string
    invoice: Invoice
    productsList: Product1[]
    constructor(private service: InvoiceService, private router: Router) {
        this.orderid = sessionStorage.getItem('tid')
        this.change();
        this.showinvoice();
    }
    er: Error

    showinvoice(): any {
        this.service.showInvoice(this.orderid).subscribe(data => {
        this.invoice = data.invoiceObject
            this.productsList = data.productsList
        },
            err => this.er = err)
    }

    ch = false;
    change() {
        this.ch = true
    }

    backtohome(){
        this.router.navigate(['home'])
    }
    rating(){
        this.router.navigate(['rating'])
    }
}

