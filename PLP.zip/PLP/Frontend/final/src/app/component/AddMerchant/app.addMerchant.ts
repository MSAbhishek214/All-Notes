import {AdminService} from '../../Services/app.adminService';
import { Component, OnInit } from '@angular/core';
import {Merchant} from '../../models/Merchant';
import { Router } from '@angular/router';
import{FileUploader} from 'ng2-file-upload'

@Component({
  selector: 'app-add-merchant', 
  templateUrl: './app.addMerchant.html'
})
export class AddMerchantComponent  implements OnInit{
  uploader: FileUploader;

  isDropOver: boolean;
  ngOnInit(): void {
    const headers = [{name: 'Accept', value: 'application/json'}];

    this.uploader = new FileUploader({url: 'http://localhost:5000/admin/api/files', autoUpload: true, headers: headers});
 
    this.uploader.onCompleteAll = () => alert('File uploaded');
   
  }


  constructor(private service: AdminService, private router: Router) {

  }




  merchantId:number
  firstName:String
  lastName:String
  company:String
  emailid:String
  mobileno:number
  password:String
  photo:String
  rating:number=0
  check:boolean=false;
  messageResponse:string;
  status: string="Disapproved";


  onSelectFile(files: FileList){
    if (files.item[0]!=null) {
      var reader = new FileReader();

     reader.readAsDataURL(files.item[0]); // read file as data url

      reader.onload = (event) => { // called once readAsDataURL is completed
        this.photo = null;
      }
    }
  }
  addMerchant(): any {

    var ob: Merchant;
    // new Merchant(null,this.firstName,this.lastName,this.company,
    //   this.emailid,this.mobileno,this.password,this.photo,this.rating,this.status);
    ob.merchantId = null;
    ob.firstName = this.firstName;
    ob.lastName = this.lastName;
    ob.company = this.company;
    ob.emailid = this.emailid;
    ob.mobileno = this.mobileno;
    ob.password = this.password;
    ob.photo = this.photo;
    ob.rating = this.rating;
    ob.status = this.status;
      
    this.service.addNewMerchant(ob).subscribe(data => {
      console.log(data);
      this.messageResponse=data.message+"\n"+"Status Code: "+data.statusCode+"\n";
      alert(this.messageResponse);
      window.location.reload();
    })
    
    

    //clearing values
  this.merchantId=null
  this.firstName=null
  this.lastName=null
  this.company=null
  this.emailid=null
  this.mobileno=null
  this.password=null
  this.photo=null
  this.rating=null
  this.check=false



    }



  onCheckboxValueChange():any{
    this.check=!this.check
    if(this.check){
    this.status="Approved";
    alert(this.status)
    }
    else{
    this.status="Disapproved";
    alert(this.status)
    }
  }

  backtomerchant(){
    this.router.navigate(['showMerchant']);
  }


  print(data){
console.log(data)
  }
  }

