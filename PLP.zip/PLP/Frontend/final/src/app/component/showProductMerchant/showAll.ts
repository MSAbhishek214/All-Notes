import { Component } from "@angular/core";
import { Product } from "../../models/product";
import { ProductService } from "../../Services/ProductServiceMerchant";
import { Router } from "@angular/router";
import{FileUploader} from 'ng2-file-upload'



@Component({
    selector: 'add-comp',
    templateUrl: 'showAll.html'
})
 export class ShowProductClass{
    products1: Product[]=[];
    constructor(private  service: ProductService, private route:Router){}
  status = false;

  merchantId: number;
  
    
   object: Product = new Product();
   isDropOver: boolean;
   filler:number
   uploader: FileUploader;

    ngOnInit() {
      this.reloadData();
      this.filler=Math.random()
      const headers = [{name: 'Accept', value: 'application/json'},{name:'Number',value:this.filler.toString()}];
    
      this.uploader = new FileUploader({url: 'http://localhost:4000/api/files', autoUpload: false, headers: headers});
    
      this.uploader.onCompleteAll = () => alert('File uploaded');
    }     
         reloadData() {
           this.service.getProductsList().subscribe(
             res=>{this.products1 = res
            this.getPhoto()
            }
           )
         }
         getPhoto(){
          for(let data of this.products1){
            data.photo="http://127.0.0.1:8887/"+data.photo.substring(25)
          }
         }

 Imagestatus:boolean=false
onFileChanged(event){

  this.object.photo="D:\\Users\\habauska\\Desktop\\"+this.filler+event.target.files[0].name
  this.Imagestatus=true

}
    
         OnUpdateProduct(index: number){
         
            this.object.productID = this.products1[index].productID;
            this.object.productName = this.products1[index].productName;
            this.object.merchant = this.products1[index].merchant;
            this.merchantId = this.products1[index].merchant.merchantId;
            this.object.tag=this.products1[index].tag;
            this.object.company=this.products1[index].company;
            this.object.description=this.products1[index].description;
            this.object.photo=this.products1[index].photo;
            this.object.quantity =this.products1[index].quantity;
            this.object.category=this.products1[index].category;
            this.object.subcategory=this.products1[index].subcategory;
            this.object.soldQuantities=this.products1[index].soldQuantities;
            this.object.price=this.products1[index].price;
            this.object.releaseDate=this.products1[index].releaseDate;
             this.status = true;
             this.route.navigate(['updateProduct',])
          }   
          update() {
            if(this.Imagestatus===true){
              console.log("Hello Error")
            this.uploader.uploadAll()}
            this.service.updateProduct(this.object).subscribe( data => {console.log(data)
              this.service.getProductsList().subscribe(
                res=>{this.products1 = res
                for(let data of this.products1){
                  data.photo="http://127.0.0.1:8887/"+data.photo.substring(25)
                  console.log(data.photo)
                }
                }
              )
            },
                error => console.log(error));
                this.status = false;
                this.Imagestatus=false
          } 
    goToAddProduct(){
      this.route.navigate(['addProduct']);
    }}