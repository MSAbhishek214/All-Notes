import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { User } from "../../models/User";
import { DataService } from "../../Services/dataserviceUser";
import{FileUploader} from 'ng2-file-upload'
// import { updateClassProp } from "@angular/core/src/render3/styling";

@Component({
    selector: 'update',
    templateUrl: 'update_customer.html'
})

export class UpdateCustomerComponent implements OnInit{
    
  uploader: FileUploader;

  isDropOver: boolean;
  filler:number
    ngOnInit(): void {
        this.filler=Math.random()
        let headers = [{name: 'Accept', value: 'application/json'},{name:'Number',value:this.filler.toString()}];

        this.uploader = new FileUploader({url: 'http://localhost:5000/api/files', autoUpload: false, headers: headers});
     
        this.uploader.onCompleteAll = () => alert('File uploaded');
    }
    model: User = new User(null,null,null,null,null,null,null,null);

    constructor(private service: DataService, private router: Router) { }
    // id:number = 18
    // pass:string="UcOLDZV0dueVWN/K019ATA=="

    onFileChanged(event){
        this.model.photo="D:\\Users\\tanmpath\\Desktop\\"+this.filler+event.target.files[0].name
    }
    update() {
        // function upload1(){
        //     return new Promise((resolve,reject)=>{
        //         console.log("First")
        //     })
        // }
        // function upload2(){
        //     return new Promise((resolve,reject)=>{
        //         console.log("Second")
        //     })
        // }
        
        this.model.userId = parseInt(sessionStorage.getItem("user"))
        this.model.password = sessionStorage.getItem("userpass")
        this.uploader.uploadAll()
        alert("Account Updated !");
        //alert(this.model.password+" "+this.model.userId+" "+this.model.emailid+" "+this.model.mobileNo+" "+this.model.firstName+" "+this.model.lastName)
        this.service.update(this.model).subscribe(
            res => {
            console.log(res)
            },
            err => {
                alert("an error has occured")
            }

        )
        
        this.router.navigate(['customerprofile'])
        // window.location("http://localhost:4200/customer");    }
    // us = false;
    // change() {
    //     this.us = true;
    // }

}}