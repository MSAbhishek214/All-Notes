import { Component, OnInit, OnChanges } from '@angular/core';
import { Router } from '@angular/router';
import { DataService } from '../../Services/dataserviceUser';
import { User } from 'src/app/models/User';
// export class user
// {
//     constructor(
       
//     ){}
//      userId:number
//      emailid:string
//      firstName:String
//      lastName:string
//      password:string
//      mobileNo:number
//      address:string
//      photo:string
    
// }

@Component({
    selector: 'customer',
    templateUrl: 'customer.html',
    styleUrls: ['style.css']
})
export class CustomerComponent implements OnChanges,OnInit{
    static num:number=0
    str3:string

    ngOnInit(): void {
          this.refreshData(this.uid)
          
    }
    ngOnChanges(): void {
        
    } 
    constructor(private router:Router, private service:DataService){
        this.str3 = sessionStorage.getItem('user')
        if(this.str3 == null){
          this.router.navigate(['home'])
        }
    }

    
    uid:string = sessionStorage.getItem("user")
    customerDetails:User = new User(null,null,null,null,null,null,null,null);
    
    refreshData(uid)
    {
        let promise = new Promise((resolve, reject) => {
            setTimeout(() => {
                this.service.display(this.uid).subscribe(
                    data=>{
                        console.log(data)
                        this.customerDetails = data
                        console.log(this.customerDetails.photo)
                        this.customerDetails.photo="http://127.0.0.1:8887/"+this.customerDetails.photo.substring(25)
                    }
                )
              resolve();
            }, 100);
          });
        // this.service.display(this.uid).subscribe(
        //     data=>{
        //         console.log(data)
        //         this.customerDetails = data
        //         console.log(this.customerDetails.photo)
        //          this.customerDetails.photo="http://127.0.0.1:8887/"+this.customerDetails.photo.substring(55)
        //     }
        // )
        
        
    }
    

    // customer()
    // {
    //     this.router.navigate(['customer'])
    // }
}