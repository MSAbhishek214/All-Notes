import { Component } from '@angular/core';
import { dataService } from '../../Services/dataServiceMerchant';
import { Merchant } from '../../models/merchant';
import { Router } from '@angular/router';

@Component({
    selector: 'merchant',
    templateUrl: 'merchant.html'
})

export class MerchantComponent {

    merchant:Merchant = new Merchant()
    mid:string
    str3:string

    constructor( private service:dataService,private router:Router){
        this.str3 = sessionStorage.getItem('merchant')
    if(this.str3 == null){
      this.router.navigate(['home'])
    }

        this.mid = sessionStorage.getItem("merchant")
       this.refreshData(this.mid)
    }

    

    
    refreshData(mid){
    this.service.fetchMerchantDetails(this.mid).subscribe(
        data=>{
            console.log(data)
            this.merchant = data
            
        }
    )
    }
}