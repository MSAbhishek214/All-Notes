import { AdminService } from "../../services/app.adminService";
import { Component } from "@angular/core";
import { Product } from "../../models/Product";
import { Router } from "@angular/router";
import { FormGroup, FormBuilder } from "@angular/forms";
import { CapStoreSearchService } from "src/app/Services/app.CapStoreSearchService";

@Component({
  selector: 'add-comp',
  templateUrl: 'showProduct.html'
})
export class ShowProductComponent {
  products1: Product[] = [];
  constructor(private service: AdminService, private route: Router, private fb: FormBuilder, private searchService: CapStoreSearchService) { }
  status = false;

  merchantId: number;


  object: Product = new Product();


  ngOnInit() {
    this.search = "name";
    this.reloadData();
  }
  reloadData() {
    this.service.getProductsList().subscribe(
      res => {this.products1 = res
      for(let data of this.products1){
        data.photo="http://127.0.0.1:8887/"+data.photo.substring(25)
      }
      }
    )
  }


  categoryForm: FormGroup;

  OnUpdateProduct(index: number) {

    this.object.productID = this.products1[index].productID;
    this.object.productName = this.products1[index].productName;
    this.object.merchant = this.products1[index].merchant;
    this.merchantId = this.products1[index].merchant.merchantId;
    this.object.tag = this.products1[index].tag;
    this.object.company = this.products1[index].company;
    this.object.description = this.products1[index].description;
    this.object.photo = this.products1[index].photo;
    this.object.quantity = this.products1[index].quantity;
    this.object.category = this.products1[index].category;
    this.categoryForm = this.fb.group({
      categoryControl: [this.object.category]
    });
    this.object.subcategory = this.products1[index].subcategory;
    this.object.soldQuantities = this.products1[index].soldQuantities;
    this.object.price = this.products1[index].price;
    this.object.releaseDate = this.products1[index].releaseDate;
    this.status = true;
  }
  update() {
    this.service.updateProduct(this.object).subscribe(data => {
      console.log(data)
      this.service.getProductsList().subscribe(
        res => this.products1 = res
      )
    },
      error => console.log(error));
    this.status = false;
  }
  goToAddProduct() {
    this.route.navigate(['addProduct']);
  }
  backtoadmin() {
    this.route.navigate(['admin']);

  }

  onChange($event) {
    this.object.category = $event.target.options[$event.target.options.selectedIndex].value;
    console.log(this.object.category)
  }


  search: string;
  value: string;

  findProduct() {
    if(this.value===""){
      // alert("this")
      this.reloadData();}
    

    else if (this.search === "name")
      this.searchService.findbyProductName(this.value).subscribe(
        res => {
          this.products1 = res;
          console.log(res)
        },
        err => {
          // alert("An error has occurred 1")
        }
      )

    else(this.search === "company")
      this.searchService.findbyCompanyName(this.value).subscribe(
        res => {
          this.products1 = res;
          console.log(res)
        },
        err => {
          // alert("An error has occurred 2")
        }
      )


  }




}
