package com.cg.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.cg.bean.Return;
import com.cg.bean.Transaction;

public interface ReturnDAO extends JpaRepository<Return, Integer> {

	@Query("select r.transaction from Return r where r.transaction=?1")
	public Transaction checksExists(Transaction transaction);

	@Transactional
	@Modifying
	@Query("update Return r set r.returnStatus='\"refund approved\"' where r.transaction=?1")
	public void approveRefund(Transaction transactionObject);
}
