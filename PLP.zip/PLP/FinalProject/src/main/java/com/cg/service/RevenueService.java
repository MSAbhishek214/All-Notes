package com.cg.service;

public interface RevenueService {
	public void updateCapStoreRevenue(Double total);

}