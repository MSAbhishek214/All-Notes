package com.cg.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.bean.Return;
import com.cg.bean.Transaction;
import com.cg.bean.User1;
import com.cg.dao.CapStoreDAO;
import com.cg.dao.ProductDAO;
import com.cg.dao.ReturnDAO;
import com.cg.dao.TransactionDAO;
import com.cg.dao.User1DAO;


@Service("returnService")
public class ReturnService implements IReturnService {

	@Autowired
	public ReturnDAO returnDao;
	@Autowired
	TransactionDAO transactdao;
	@Autowired
	User1DAO userdao;
	
	@Autowired
	CapStoreDAO capstoredao;
	
	@Autowired
	ProductDAO productdao;
	
	@Override
	public List<Return> getAllReturnDetails() {
		return returnDao.findAll();
	}

	@Override
/*	public Return addrecordtoreturn(int temp) {

		Optional<Transaction> box = transactdao.findById(temp);
		if (box.isPresent()) {
			List<Return> returnlist = returnDao.findAll();
			returnlist = returnlist.stream().filter(ele -> {
				if (ele.getTransaction().getTransactionId() == temp) {
					return true;
				} else {
					return false;
				}
			}).collect(Collectors.toList());

			if (returnlist.size() > 0) {
				return null;
			} else {
				Return myreturn = new Return();
				myreturn.setTransaction(box.get());
				myreturn.setPickupDate(new Date());
				myreturn.setReturnStatus("success");
				returnDao.save(myreturn);
				return myreturn;

			}
		} else {
			return null;
		}

	}   */
	
	public Return addrecordtoreturn(int temp) {
        Return myreturn = new Return();

        Transaction myorder = transactdao.findById(temp).get();
        
        if(myorder.getStatus().equals("Delivered") && myorder!=null) {
        	myreturn.setTransaction(myorder);
    		myreturn.setPickupDate(new Date());
    		
    		myreturn.setReturnStatus("success");
    		myorder.setStatus("Returned");
    	    returnDao.saveAndFlush(myreturn);
    	    transactdao.saveAndFlush(myorder);
    	    this.approveRefund(temp);
    	    return myreturn;
        }else {
        	return myreturn;
        }

	}
	@Transactional
	public void approveRefund(Integer transactionId) {
		// TODO Auto-generated method stub
		
		Transaction transactionObject=transactdao.findById(transactionId).get();
		returnDao.approveRefund( transactionObject);
		updateRevenue(transactionId);
	}



	public void updateRevenue(Integer transactionId) {
		
		
		Double total=0.0;
		Double price=0.0;
		
		Transaction transactionObject=transactdao.findById(transactionId).get();
		
		List<Integer[]> productsList=transactionObject.getProducts();
		
		for(Integer[] productDetails:productsList) {
			
				price=productdao.getOne(productDetails[0]).getPrice();
				total+=productDetails[1]*price;
			
		}
		
		capstoredao.updateRevenueForRefund(total);
		
		
	}
	public List<Integer> getTransaction(int userid){
//		List<Transaction> list=transactdao.findAll();
//		List<Integer> transactList=new ArrayList<Integer>();
// 		for(Transaction data:list) {
// 			if(data.getUser().getUserId()==userid) {
// 				transactList.add(data.getTransactionId());
// 			}
// 		}
//		return transactList;
		
		List<Transaction> transactionList=null;
		System.out.println(userid);
		User1 userObject=userdao.findById(userid).get();
		System.out.println(userObject);
		
		transactionList=transactdao.getAllTransactionByUser(userObject);
		
		if(transactionList.isEmpty() && transactionList==null) {
			System.out.println("Transactions Not Found");
			return null;
		}
		else {
			List<Integer> idsList=new ArrayList<Integer>();
			for(Transaction t:transactionList) {

//				System.out.println(t.getTransactionId());
				idsList.add(t.getTransactionId());
				
			}
			return idsList;
			
		}
		
	}

//	@Override
//	public String addTransaction(Transaction t) {
//	
//		try {
//			transactdao.save(t);
//		}catch(Exception e)
//		{
//			return e.getMessage();
//		}
//		return "Added";
//	}
//
//	@Override
//	public List<Transaction> getAllTransactions() {
//		
//		return transactdao.findAll();
//	}
//	

	
	/*  @Override public String checkstatus(int id) { // TODO Auto-generated
	 
	 
	 
	  Transaction myorder=transactdao.findById(id).get();
	  List<Return> prodreturn = returnDao.findAll();
	  for(Return ret:prodreturn) {
	  if(ret.getTransaction().getTransactionId()==id)
	  {
		 return null;
	  }
	  else
	  }
	  
	  return null;
	  }
*/	 

/*	@Override
	public List<Return> getreturngoods() {
		// TODO Auto-generated method stub
		return returnDao.findAll();
	}

	@Override
	public Return checkstatus(int id) {
		// TODO Auto-generated method stub
		return null;
	}  */

}
