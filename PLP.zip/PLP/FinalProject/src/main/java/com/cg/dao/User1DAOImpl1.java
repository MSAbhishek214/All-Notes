package com.cg.dao;



import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cg.bean.User1;



@Repository
public class User1DAOImpl1 implements User1DAO1 {

	@PersistenceContext
	EntityManager em;

	@Autowired
	TransactionDAO1 transaction;

	@SuppressWarnings("unchecked")
	@Override
	public List<User1> user(int orderid) {
		int userid = transaction.useridorder(orderid);
		Query query = em.createQuery("select u from User1 u where u.userId = :userid");
		List<User1> userlist = query.setParameter("userid", userid).getResultList();
		return userlist;
	}

	@Override
	public User1 getUser(int userid) {
		Query query = em.createQuery("select u from User1 u where u.userId = :userid");
		User1 user = (User1) query.setParameter("userid", userid).getSingleResult();
		return user;
	}

}
