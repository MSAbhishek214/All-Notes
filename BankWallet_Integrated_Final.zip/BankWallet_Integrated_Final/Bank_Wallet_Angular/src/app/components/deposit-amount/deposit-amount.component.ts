import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { WalletService } from 'src/app/services/wallet.service';
import { SampleResponse } from 'src/app/models/SampleResponse.model';
@Component({
  selector: 'app-deposit-amount',
  templateUrl: './deposit-amount.component.html',
  styleUrls: ['./deposit-amount.component.css']
})
export class DepositAmountComponent implements OnInit {
  depositForm: FormGroup;
  response: SampleResponse;
  constructor(private service: WalletService, private formBuilder: FormBuilder) {
  }
  ngOnInit() {
    this.depositForm = this.formBuilder.group({
      accountNum: ['', [Validators.required, Validators.pattern("^[A-Z]{3}\\d{10}$")]],
      amount: ['', [Validators.required, Validators.pattern("^[1-9][0-9]*$")]],
      password: ['', Validators.required]
    });
  }
  get formControls() { return this.depositForm.controls; }
  onSubmit() {
    if (this.depositForm.invalid) {
      return;
    }
    let accountNum: string = this.formControls.accountNum.value;
    let amount: number = parseFloat(this.formControls.amount.value);
    let password: string = this.formControls.password.value;
    this.deposit(amount, accountNum,password);
  }
  deposit(amount: number, accountNum: string,password: string) {
    this.service.deposit(amount, accountNum, password).then(response => { this.response = response;
      alert("Deposit successful. New balance is ".concat(this.response.result['balance']));
    }
      , err => {
        if (err.success != undefined && err.success == false) {
          this.response = err;
        }
      });
  }

}
