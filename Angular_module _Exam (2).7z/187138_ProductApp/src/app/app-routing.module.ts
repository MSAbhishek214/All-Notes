import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProductsearchComponent } from './products/productsearch/productsearch.component';
import { ProductlistComponent } from './products/productlist/productlist.component';


const routes: Routes = [
  {path:"SearchForm",component:ProductsearchComponent},
  {path:"ProductList",component:ProductlistComponent},
  {path:"",component:ProductsearchComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
