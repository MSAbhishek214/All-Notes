import { Component, OnInit } from '@angular/core';
import { IProduct } from 'src/app/product/product.interface';
import { ProductService } from 'src/app/product/product.service';

@Component({
  selector: 'app-productsearch',
  templateUrl: './productsearch.component.html',
  styleUrls: ['./productsearch.component.css']
})
export class ProductsearchComponent implements OnInit {
  products:IProduct[];

  constructor(private productservice: ProductService) { }
  ngOnInit() {
  }
  /**
   * In this method the data we search it will show.
   * 
   */
  searchProduct(data){
    console.log(data);
    this.products=this.productservice.getData();
    this.products=this.products.filter(s=>(s.name==data.any || s.category==data.any));
    console.log(this.products);
  }
}
