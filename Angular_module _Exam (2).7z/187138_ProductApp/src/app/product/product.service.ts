import { Injectable } from '@angular/core';
import { IProduct } from './product.interface';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
@Injectable({
 providedIn: 'root'
})
export class ProductService {
 products:IProduct[];
 
 
 constructor(private http:HttpClient) {
 this.getProducts().subscribe(data=>this.products=data);
 }
 getProducts():Observable<IProduct[]>{
 return this.http.get<IProduct[]>("../../assets/db.json");
 }
 getData(){
 return this.products;
 }
 
 setProducts(products:IProduct[]){
 this.products=products;
 }
 deleteProduct(name:string){
 this.products=this.products.filter(s=>s.name!=name);
 }
}