package com.cg.order.services;

import java.util.List;

import com.cg.order.beans.Order;
import com.cg.order.exceptions.OrderException;

public interface OrderService {

	List<Order> getAllOrders() throws OrderException;

	List<Order> addOrder(Order order) throws OrderException;

	List<Order> updateOrder(Order order, int id) throws OrderException;

	List<Order> getOrdersByQuantityRange(int minQuantity, int maxQuantity) throws OrderException;

	List<Order> getOrdersByAmount(double amount) throws OrderException;

}
