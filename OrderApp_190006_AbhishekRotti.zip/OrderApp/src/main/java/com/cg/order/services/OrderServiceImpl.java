package com.cg.order.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.order.beans.Order;
import com.cg.order.dao.OrderRepository;
import com.cg.order.exceptions.OrderException;

@Service
public class OrderServiceImpl implements OrderService {

	@Autowired
	private OrderRepository orderRepository;
	
	@Override
	public List<Order> getAllOrders() throws OrderException {
		return orderRepository.findAll();
	}

	@Override
	public List<Order> addOrder(Order order) throws OrderException {
		if(orderRepository.existsById(order.getId())) {
			throw new OrderException("Order with ID" + order.getId() + " already exists");
		}
		if(order.getQuantity() < 1) {
			throw new OrderException("Quantity cannot be less than 1!!!");
		}
		double amount = order.getPrice() * 75 * order.getQuantity();
		double charges = amount * (1.25 / 100);
		order.setAmount(amount);
		order.setCharges(charges);
		orderRepository.save(order);
		return getAllOrders();
	}

	@Override
	public List<Order> updateOrder(Order order, int id) throws OrderException {
		// checks if the id exists
		if(!orderRepository.existsById(id)) {
			throw new OrderException("Order Id " + id + " does not exist, update operation disallowed");
		}
		// original order is used for saving back to database
		Order originalOrder = orderRepository.findById(id).get();
		double amount = order.getPrice() * 75 * order.getQuantity();
		double charges = amount * (1.25 / 100);
		originalOrder.setPrice(order.getPrice());
		originalOrder.setQuantity(order.getQuantity());
		originalOrder.setAmount(amount);
		originalOrder.setCharges(charges);
		orderRepository.save(originalOrder);
		return getAllOrders();
	}

	@Override
	public List<Order> getOrdersByQuantityRange(int minQuantity, int maxQuantity) throws OrderException {
		return orderRepository.getOrdersByQuantityRange(minQuantity, maxQuantity);
	}

	@Override
	public List<Order> getOrdersByAmount(double amount) throws OrderException {
		return orderRepository.getOrdersByAmount(amount);
	}

}
