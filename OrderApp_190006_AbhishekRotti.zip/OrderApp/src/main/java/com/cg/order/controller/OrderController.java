package com.cg.order.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.order.beans.Order;
import com.cg.order.exceptions.OrderException;
import com.cg.order.services.OrderService;

@RestController // home controller
@RequestMapping("/orders") // home url
public class OrderController {

	@Autowired // get the order service injection
	private OrderService orderService;

	@RequestMapping("/viewall") // gives a list of all the orders
	public List<Order> getAllOrders() throws OrderException {
		return orderService.getAllOrders();
	}

	@PostMapping("/addorder") // adds an order and calculates amount and charges accordingly
	public List<Order> addOrder(@RequestBody Order order) throws OrderException {
		return orderService.addOrder(order);
	}

	@PutMapping("/updateorder/{id}") // updates the order and calculates new amount and charges accordingly
	public List<Order> updateOrder(@RequestBody Order order, @PathVariable int id) throws OrderException {
		return orderService.updateOrder(order, id);
	}

	@GetMapping("/orderbyquantityrange/{minQuantity}/{maxQuantity}") // returns a list with quantity between min and max range
	public List<Order> getOrdersByQuantityRange(@PathVariable int minQuantity, @PathVariable int maxQuantity)
			throws OrderException {
		return orderService.getOrdersByQuantityRange(minQuantity, maxQuantity);
	}

	@GetMapping("/orderbyamount/{amount}") // returns a list with orders greater than amount specified by user
	public List<Order> getOrdersByAmount(@PathVariable double amount) throws OrderException {
		return orderService.getOrdersByAmount(amount);
	}

}
