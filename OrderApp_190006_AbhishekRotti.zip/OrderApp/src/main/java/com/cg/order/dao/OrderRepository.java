package com.cg.order.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.order.beans.Order;

@Repository
public interface OrderRepository extends JpaRepository<Order, Integer> {

	@Query("from Order where quantity between :minQuantity AND :maxQuantity")
	List<Order> getOrdersByQuantityRange(@Param("minQuantity") int minQuantity, @Param("maxQuantity") int maxQuantity);
	
	@Query("from Order where amount > :amount")
	List<Order> getOrdersByAmount(@Param("amount") double amount);
}
