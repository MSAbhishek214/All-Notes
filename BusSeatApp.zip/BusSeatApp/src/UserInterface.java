import java.util.Scanner;


public class UserInterface {
	public static void main(String a[]) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter name:");
		String name=sc.next();
		System.out.println("Enter gender:");
		char gender=sc.next().charAt(0);
		System.out.println("Enter age:");
		int age=sc.nextInt();
		System.out.println("Enter seat Number:");
		int seatNo=sc.nextInt();
		Customer cObj=new Customer();
		cObj.setCustomerName(name);
		cObj.setGender(gender);
		cObj.setAge(age);
		try {
			cObj.setSeatNo(seatNo);
			System.out.println("Seat number allocated");
		} catch(SeatNoNotValidException e) {
			System.out.println(e.getMessage());
		}
	}
}
