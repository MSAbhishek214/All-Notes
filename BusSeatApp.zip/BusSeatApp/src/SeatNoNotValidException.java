//make the necessary change to make this class a Exception 
public class SeatNoNotValidException extends Exception{
	public SeatNoNotValidException(String message) {
	    super(message);
	}
}

