import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

public class AccountTest {
	
	@Test
	public void testDeposit1() {
		Account acc = new Account(1, "Savings", 1000);
		boolean expected = true;
		boolean actual = acc.deposit(1000);
		assertEquals(expected, actual);
	}
	
	@Test
	public void testDeposit2() {
		Account acc = new Account(1, "Savings", 1000);
		boolean expected = false;
		boolean actual = acc.deposit(-1000);
		assertEquals(expected, actual);
	}
}
